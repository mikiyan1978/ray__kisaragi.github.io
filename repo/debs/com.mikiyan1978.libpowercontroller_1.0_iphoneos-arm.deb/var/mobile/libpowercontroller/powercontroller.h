#import <notify.h>
#import <objc/runtime.h>
#import <spawn.h>
#import <sys/wait.h>

@interface FBSystemService : NSObject
+(id)sharedInstance; //existing presence of object

-(void)shutdownAndReboot:(BOOL)arg1; //shutting down with the option to reboot (the boolean value)

-(void)exitAndRelaunch:(BOOL)arg1; //restart the FrontBoard process (thus restarting SpringBoard as well; the boolean value has no change, the process restarts anyway)

-(void)nonExistantMethod; //fake method to crash in a safe way, loading SafeMode
@end




